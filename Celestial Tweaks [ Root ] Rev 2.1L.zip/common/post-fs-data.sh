#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

disable_kernel_panic() {
  for KERNEL_PANIC in $(find /proc/sys/ /sys/ -name '*panic*'); do
    echo "0" > "$KERNEL_PANIC"
  done
  
    sysctl -w kernel.panic=0
    sysctl -w vm.panic_on_oom=0
    sysctl -w kernel.panic_on_oops=0
    sysctl -w kernel.softlockup_panic=0
}

disable_printk() {
# Printk (thx to KNTD-reborn)
    echo "0 0 0 0" > /proc/sys/kernel/printk
    echo "off" > /proc/sys/kernel/printk_devkmsg
    echo "1" > /sys/module/printk/parameters/ignore_loglevel
    echo "1" > /sys/module/printk/parameters/console_suspend
    echo "0" > /sys/module/printk/parameters/cpu
    echo "0" > /sys/kernel/printk_mode/printk_mode
    echo "0" > /sys/module/printk/parameters/pid
    echo "0" > /sys/module/printk/parameters/time
    echo "0" > /sys/module/printk/parameters/printk_ratelimit
}

other_disable_logger() {
    cmd stats clear-puller-cache
    logcat -c --wrap
    simpleperf --log fatal --log-to-android-buffer 0
    cmd activity clear-watch-heap -a
}

other_tweak_setprop() {
 # thx to (yexCm) https://xdaforums.com/t/magisk-module-make-your-phone-as-smooth-as-ios.4616997/
    resetprop -n debug.sf.use_phase_offsets_as_durations 1
    resetprop -n debug.sf.late.sf.duration 10500000
    resetprop -n debug.sf.late.app.duration 16600000
    resetprop -n debug.sf.treat_170m_as_sRGB 1
    resetprop -n debug.sf.earlyGl.app.duration 16600000
    resetprop -n debug.sf.frame_rate_multiple_threshold 120
    
    #LMKD by @WisnuArdhi34
    resetprop -n lmk.debug.enabled false
    resetprop -n lmk.log_stats false
    resetprop -n lmk.critical_upgrade.enabled true
    resetprop -n lmk.upgrade_pressure 40
    resetprop -n lmk.downgrade_pressure 60
}

main() {
    optimize_dropbox
    disable_debugging_features
    disable_kernel_panic
    disable_printk
    other_disable_logger
    other_tweak_setprop
}

# Main Execution & Exit script successfully
sync && main
  
# This script will be executed in post-fs-data mode